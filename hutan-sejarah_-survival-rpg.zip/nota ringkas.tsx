/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sword, 
  Shield, 
  BookOpen, 
  RotateCcw, 
  ChevronRight, 
  FileText, 
  Share2, 
  Milestone,
  X,
  ExternalLink
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** --- UTILS --- **/
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** --- NOTES DATA --- **/
const NOTA_RINGKAS = [
  {
    perihal: "Bab 1: Warisan Kesultanan Melayu Melaka (KMM)",
    isi: [
      "KMM merupakan asas kenegaraan Malaysia.",
      "Ciri KMM: Kerajaan, Rakyat, Kedaulatan, Wilayah Pengaruh, Undang-undang, Lambang Kebesaran.",
      "Sistem Pentadbiran: Sistem Pembesar Empat Lipatan (Bendahara, Penghulu Bendahari, Temenggung, Laksamana).",
      "Undang-undang: Hukum Kanun Melaka (44 fasal) & Undang-undang Laut Melaka."
    ]
  },
  {
    perihal: "Bab 2: Kebangkitan Nasionalisme",
    isi: [
      "Nasionalisme: Perasaan cinta yang mendalam terhadap bangsa dan tanah air.",
      "Tokoh Luar: Jose Rizal (Filipina), Mahatma Gandhi (India), Sun Yat-sen (China).",
      "Faktor di Tanah Melayu: Peranan agama (Gerakan Islah), Penulisan kreatif (Novel/Cerpen), Media cetak (Akhbar Al-Ikhwan/Majlis).",
      "Pertubuhan: Kesatuan Melayu Muda (KMM) - memperjuangkan Melayu Raya."
    ]
  },
  {
    perihal: "Bab 3: Konflik Dunia & Pendudukan Jepun",
    isi: [
      "PD1: Berlaku 1914-1918. Faktor: Persaingan kuasa imperialis & Pembunuhan Archduke Franz Ferdinand.",
      "PD2: Berlaku di Eropah & Asia Pasifik. Jepun menyerang Tanah Melayu pada 8 Dis 1941.",
      "Slogan Jepun: 'Asia untuk Orang Asia' & 'Semangat Asia'.",
      "Penentangan: Force 136 (Gerila Melayu/British), MPAJA, Wataniah Pahang."
    ]
  },
  {
    perihal: "Bab 4 - 10: Menuju Kemerdekaan",
    isi: [
      "Malayan Union 1946: Bantahan besar-besaran orang Melayu diketuai Dato' Onn Jaafar.",
      "PTM 1948: Menggantikan Malayan Union, mengembalikan kedaulatan Raja-raja.",
      "Darurat (1948-1960): Menentang ancaman komunis. Rancangan Briggs (Kampung Baru).",
      "Rundingan London: Tunku Abdul Rahman mengetuai rombongan pada 1956.",
      "Kemerdekaan: Diisytiharkan pada 31 Ogos 1957 di Stadium Merdeka."
    ]
  }
];

/** --- MOCK DATA (40 QUESTIONS - FORM 4 SEJARAH) --- **/
const MOCK_QUESTIONS = [
  // Bab 1: Warisan Kesultanan Melayu Melaka
  { q: "Apakah ciri kedaulatan Kesultanan Melayu Melaka?", a: ["Rakyat", "Wilayah Pengaruh", "Kedaulatan", "Semua di atas"], c: 3, e: "Ciri kedaulatan KMM merangkumi Kerajaan, Rakyat, Kedaulatan, Wilayah Pengaruh, Undang-undang, dan Lambang Kebesaran." },
  { q: "Siapakah yang mengetuai pentadbiran peringkat pusat dalam KMM?", a: ["Laksamana", "Bendahara", "Temenggung", "Syahbandar"], c: 1, e: "Bendahara bertindak sebagai Ketua Pentadbir dan Ketua Turus Angkatan Tentera." },
  { q: "Hukum Kanun Melaka mempunyai berapa fasal?", a: ["22", "30", "44", "51"], c: 2, e: "Hukum Kanun Melaka mengandungi 44 fasal berkaitan bidang kuasa raja dan larangan dalam negeri." },
  { q: "Siapakah rakyat Melaka yang terdiri daripada orang Melayu dan Orang Laut?", a: ["Rakyat", "Hamba", "Pedagang", "Pembesar"], c: 0, e: "Rakyat Melaka terdiri daripada pelbagai golongan yang menunjukkan taat setia kepada Sultan." },
  
  // Bab 2: Kebangkitan Nasionalisme
  { q: "Siapakah tokoh yang mempelopori gerakan nasionalisme di Filipina?", a: ["Jose Rizal", "Soekarno", "Sayyid Jamaluddin", "Ho Chi Minh"], c: 0, e: "Jose Rizal memulakan gerakan nasionalisme di Filipina melalui Liga Filipina." },
  { q: "Akhbar Al-Ikhwan diterbitkan di negeri mana?", a: ["Selangor", "Pulau Pinang", "Singapura", "Kedah"], c: 1, e: "Akhbar Al-Ikhwan diterbitkan di Pulau Pinang untuk menyedarkan umat Islam." },
  { q: "Apakah maksud 'Nasionalisme' mengikut Hans Kohn?", a: ["Perasaan cinta tanah air", "Kesetiaan kepada negara", "Semangat kebangsaan", "Perjuangan bersenjata"], c: 1, e: "Hans Kohn mendefinisikan nasionalisme sebagai satu gerakan yang meletakkan kesetiaan kepada negara." },
  { q: "Persatuan Sahabat Pena Malaya (PASPAM) ditubuhkan pada tahun?", a: ["1930", "1934", "1938", "1940"], c: 1, e: "PASPAM ditubuhkan pada tahun 1934 untuk menggalakkan persaudaraan dalam kalangan orang Melayu." },

  // Bab 3: Konflik Dunia & Pendudukan Jepun
  { q: "Perang Dunia Pertama bermula pada tahun?", a: ["1910", "1914", "1918", "1920"], c: 1, e: "PD1 meletus pada 1914 berpunca daripada pembunuhan Archduke Franz Ferdinand." },
  { q: "Jepun menggunakan slogan apa untuk menarik minat rakyat Tanah Melayu?", a: ["Asia untuk orang Asia", "Kesejahteraan Bersama", "Jepun Maju", "Tanah Melayu Baru"], c: 0, e: "Slogan 'Asia untuk orang Asia' digunakan untuk menyingkirkan kuasa Barat." },
  { q: "Force 136 ditubuhkan oleh siapa?", a: ["British", "Jepun", "PKM", "Amerika"], c: 0, e: "Force 136 ialah pasukan gerila British yang bekerjasama dengan orang Melayu menentang Jepun." },
  { q: "Apakah tujuan penubuhan KMM oleh Ibrahim Haji Yaakob?", a: ["Kemerdekaan penuh", "Melayu Raya", "Sokong British", "Sokong Komunis"], c: 1, e: "Kesatuan Melayu Muda (KMM) memperjuangkan konsep Melayu Raya bersama Indonesia." },

  // Bab 4-10
  { q: "Malayan Union diperkenalkan pada tahun?", a: ["1945", "1946", "1947", "1948"], c: 1, e: "British memperkenalkan Malayan Union pada 1 April 1946 yang menghapuskan kedaulatan Raja-raja Melayu." },
  { q: "Siapakah Gabenor pertama Malayan Union?", a: ["Edward Gent", "Gerard Templer", "Malcolm MacDonald", "Henry Gurney"], c: 0, e: "Sir Edward Gent merupakan Gabenor pertama Malayan Union." },
  { q: "Persekutuan Tanah Melayu ditubuhkan pada 1 Feb 1948 untuk menggantikan?", a: ["British Malaya", "Malayan Union", "Crown Colony", "Borneo Utara"], c: 1, e: "PTM 1948 ditubuhkan hasil rundingan antara British, Raja-raja Melayu dan UMNO." },
  { q: "Darurat diisytiharkan pada tahun?", a: ["1946", "1948", "1950", "1952"], c: 1, e: "Sir Edward Gent mengisytiharkan darurat pada Jun 1948 selepas pembunuhan tiga pengurus ladang Eropah di Sungai Siput." },
  { q: "Rancangan Briggs bertujuan untuk?", a: ["Lawan Jepun", "Lumpuhkan sokongan komunis", "Bina sekolah", "Bina jalan raya"], c: 1, e: "Rancangan Briggs memindahkan penduduk ke Kampung Baru untuk memutuskan bekalan kepada komunis." },
  { q: "Sistem Ahli diperkenalkan pada tahun?", a: ["1951", "1953", "1955", "1957"], c: 0, e: "Sistem Ahli 1951 bertujuan memberi latihan pentadbiran kepada penduduk tempatan." },
  { q: "Rombongan Kemerdekaan ke London diketuai oleh?", a: ["Onn Jaafar", "Tunku Abdul Rahman", "Tan Cheng Lock", "V.T. Sambanthan"], c: 1, e: "Tunku Abdul Rahman mengetuai rombongan ke London pada tahun 1956." },
  { q: "Warna kuning pada Bendera Persekutuan melambangkan?", a: ["Rakyat", "Raja-raja Melayu", "Agama Islam", "Kedaulatan"], c: 1, e: "Warna kuning ialah warna diraja yang melambangkan Raja-raja Melayu." },

  { q: "Siapakah yang mengisytiharkan kemerdekaan Tanah Melayu di Stadium Merdeka?", a: ["Onn Jaafar", "Tunku Abdul Rahman", "Tan Cheng Lock", "Abdul Razak"], c: 1, e: "Tunku Abdul Rahman mengisytiharkan kemerdekaan pada 31 Ogos 1957." },
  { q: "Apakah tujuan penubuhan CLC pada 1949?", a: ["Hubungan kaum", "Sokong British", "Lawan Komunis", "Sokong Jepun"], c: 0, e: "Communities Liaison Committee (CLC) ditubuhkan untuk memupuk kerjasama antara kaum." },
  { q: "Parti Perikatan terdiri daripada UMNO, MCA dan?", a: ["PAS", "MIC", "GERAKAN", "DAP"], c: 1, e: "UMNO, MCA, and MIC membentuk Parti Perikatan untuk bertanding dalam pilihan raya." },
  { q: "Suruhanjaya Reid ditubuhkan untuk?", a: ["Lawan Komunis", "Rangka Perlembagaan", "Bentuk Kabinet", "Runding Jajahan"], c: 1, e: "Suruhanjaya Reid ditugaskan merangka Perlembagaan Persekutuan Tanah Melayu yang merdeka." },
  { q: "Pilihan Raya Umum pertama diadakan pada tahun?", a: ["1951", "1953", "1955", "1957"], c: 2, e: "Pilihan Raya Majlis Perundangan Persekutuan yang pertama diadakan pada Julai 1955." },
  { q: "Siapakah Yang di-Pertuan Agong pertama?", a: ["Tuanku Abdul Rahman", "Tuanku Hisamuddin", "Tuanku Ismail", "Tuanku Yahya"], c: 0, e: "Tuanku Abdul Rahman (Negeri Sembilan) dipilih sebagai YDPA pertama." },
  { q: "Apakah jawatan tertinggi dalam pentadbiran Malayan Union?", a: ["Sultan", "Perdana Menteri", "Gabenor", "Residen"], c: 2, e: "Gabenor dilantik sebagai ketua pentadbir Malayan Union." },
  { q: "Gerakan Islah dipimpin oleh siapa?", a: ["Kaum Muda", "Kaum Tua", "British", "Raja-raja"], c: 0, e: "Kaum Muda mempelopori gerakan Islah untuk memurnikan ajaran Islam." },
  { q: "Pertubuhan KMM diharamkan oleh?", a: ["Jepun", "British", "THAM", "PKM"], c: 1, e: "Kesatuan Melayu Muda diharamkan oleh British pada 1942." },
  { q: "Negeri manakah yang tidak menyertai PTM 1948?", a: ["Singapura", "Pulau Pinang", "Melaka", "Selangor"], c: 0, e: "Singapura kekal sebagai tanah jajahan mahkota dan tidak termasuk dalam PTM 1948." },
  { q: "Siapakah yang menentang Malayan Union secara terbuka?", a: ["Tan Cheng Lock", "Onn Jaafar", "E.E.C. Thuraisingham", "S.A. Ganapathy"], c: 1, e: "Dato' Onn Jaafar mengetuai bantahan besar-besaran orang Melayu terhadap Malayan Union." },
  { q: "Apakah nama undang-undang KMM yang berkaitan pelayaran?", a: ["Hukum Kanun Laut Melaka", "Undang-undang Laut Melayu", "Fasal Laut", "Kanun Sultan"], c: 0, e: "Hukum Kanun Laut Melaka mengatur tatacara pelayaran dan perdagangan." },
  { q: "Sultan Melaka dibantu oleh berapa orang pembesar utama?", a: ["2", "4", "6", "8"], c: 1, e: "Sistem Pembesar Empat Lipatan diamalkan dalam Kesultanan Melayu Melaka." },
  { q: "Nasionalisme di India bermula dengan pemberontakan?", a: ["Sipahi", "Satyagraha", "Garam", "Kongres"], c: 0, e: "Dahagi India (Pemberontakan Sipahi) 1857 memulakan kesedaran kebangsaan." },
  { q: "Tok Janggut mengetuai penentangan di?", a: ["Kelantan", "Terengganu", "Pahang", "Perak"], c: 0, e: "Tok Janggut menentang cukai British di Pasir Puteh, Kelantan." },
  { q: "Perjanjian London 1824 melibatkan British dan?", a: ["Belanda", "Perancis", "Portugis", "Sepanyol"], c: 0, e: "Perjanjian London 1824 membahagikan pengaruh British dan Belanda di Kepulauan Melayu." },
  { q: "Berapakah jumlah bintang pada Bintang Persekutuan Jalur Gemilang?", a: ["11", "13", "14", "15"], c: 2, e: "Bintang pecah 14 melambangkan perpaduan 13 buah negeri dan Kerajaan Persekutuan." },
  { q: "Perang Dunia Kedua di Asia bermula apabila Jepun menyerang?", a: ["Pearl Harbor", "Kota Bharu", "Manila", "Singapura"], c: 1, e: "Pendaratan Jepun di Kota Bharu bermula pada 8 Disember 1941." },
  { q: "Lagu Negaraku berasal daripada lagu?", a: ["Terang Bulan", "Maju Jaya", "Negeri Perak", "Selat Melaka"], c: 0, e: "Irama lagu Negaraku diambil daripada lagu 'Terang Bulan'." },
  { q: "Berapakah kerusi yang dimenangi Perikatan pada PRU 1955?", a: ["51/52", "50/52", "49/52", "52/52"], c: 0, e: "Parti Perikatan menang 51 daripada 52 kerusi yang dipertandingkan." }
];

export default function SejarahSurvivalGame() {
  // Game States
  const [gameState, setGameState] = useState<'start' | 'battle' | 'explanation' | 'result'>('start');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [shake, setShake] = useState(false);
  const [activeNote, setActiveNote] = useState<'ringkas' | 'peta' | 'timeline' | null>(null);

  // Constants
  const TIMER_TOTAL = 15;

  // Battle Logic
  const handleAnswer = useCallback((index: number | null) => {
    const isCorrect = index === MOCK_QUESTIONS[currentIdx].c;

    if (isCorrect) {
      setTimeout(() => {
        if (currentIdx === MOCK_QUESTIONS.length - 1) {
          setGameState('result');
        } else {
          setCurrentIdx(prev => prev + 1);
          setTimeLeft(TIMER_TOTAL);
        }
      }, 500);
    } else {
      setShake(true);
      setTimeout(() => setShake(false), 500);
      setTimeout(() => {
        setGameState('explanation');
      }, 500);
    }
  }, [currentIdx]);

  // Timer Effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (gameState === 'battle' && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (timeLeft === 0 && gameState === 'battle') {
      handleAnswer(null);
    }
    return () => clearInterval(timer);
  }, [timeLeft, gameState, handleAnswer]);

  const resetGame = () => {
    setCurrentIdx(0);
    setTimeLeft(TIMER_TOTAL);
    setGameState('battle');
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex flex-col items-center justify-center p-6 md:p-10 overflow-hidden selection:bg-amber-500/30 font-sans relative">
      {/* Background Ambience */}
      <div className="fixed inset-0 z-0 arena-bg pointer-events-none" />
      <div className="fixed inset-0 z-0 opacity-30 pointer-events-none" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/dark-matter.png')" }} />

      <AnimatePresence mode="wait">
        {/* START SCREEN */}
        {gameState === 'start' && (
          <motion.div 
            key="start"
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="relative z-10 text-center max-w-lg"
          >
            <span className="text-amber-500 uppercase tracking-[0.3em] text-xs font-bold mb-2 block">Sejarah Survival</span>
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-slate-100 mb-6 tracking-tight leading-tight">Hutan Sejarah</h1>
            <p className="text-slate-400 mb-8 leading-relaxed text-lg">
              Kalahkan raksasa "Lupa" dengan menjawab 40 soalan sejarah Form 4 dengan tepat. Tiada HP, hanya ilmu dan kelajuan.
            </p>
            <button 
              onClick={() => setGameState('battle')}
              className="bg-amber-600 hover:bg-amber-500 text-white px-10 py-5 rounded-full font-bold text-xl shadow-[0_0_30px_rgba(217,119,6,0.2)] transition-all flex items-center gap-3 mx-auto cursor-pointer group"
            >
              Masuk ke Hutan <Sword size={24} className="group-hover:rotate-12 transition-transform" />
            </button>
          </motion.div>
        )}

        {/* BATTLE SCREEN */}
        {(gameState === 'battle' || gameState === 'explanation') && (
          <motion.div 
            key="battle"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className={cn("relative z-10 w-full max-w-4xl flex flex-col h-full", shake && "animate-shake")}
          >
            <header className="flex justify-between items-start mb-12">
              <div className="flex flex-col">
                <span className="text-amber-500 uppercase tracking-[0.3em] text-[10px] font-bold mb-1">Bab {Math.floor(currentIdx / 4) + 1}</span>
                <h1 className="font-serif text-4xl font-bold text-slate-100">Hutan Sejarah</h1>
              </div>
              <div className="text-right flex flex-col items-end">
                <span className="text-slate-500 uppercase tracking-widest text-[10px] font-bold mb-2">Masa Berbaki</span>
                <div className={cn(
                  "timer-ring transition-colors duration-500 bg-slate-900 shadow-xl",
                  timeLeft <= 5 ? "border-rose-500 text-rose-500 shadow-rose-500/30" : "border-amber-500 text-amber-500"
                )}>
                  {timeLeft}s
                </div>
              </div>
            </header>

            <div className="h-48 relative flex items-center justify-around mb-12">
              <div className="w-48 h-48 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center relative overflow-hidden backdrop-blur-sm">
                <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 4 }}>
                   <Shield size={64} className="text-emerald-500 opacity-60" />
                </motion.div>
              </div>
              <div className="font-serif text-5xl font-black text-slate-800 absolute opacity-20 tracking-tighter">VS</div>
              <div className="w-48 h-48 rounded-full bg-rose-500/10 border border-rose-500/20 flex items-center justify-center relative overflow-hidden backdrop-blur-sm">
                <motion.div animate={{ scale: [1, 1.15, 1], rotate: [0, 5, -5, 0] }} transition={{ repeat: Infinity, duration: 3 }}>
                  <Sword size={64} className="text-rose-500 opacity-60" />
                </motion.div>
              </div>
            </div>

            <div className="relative flex-grow">
              <AnimatePresence mode="wait">
                {gameState === 'battle' ? (
                  <motion.div 
                    key={currentIdx}
                    initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -20, opacity: 0 }}
                    className="bg-slate-900/80 backdrop-blur-md border border-slate-800 p-8 md:p-10 rounded-3xl shadow-2xl relative z-10"
                  >
                    <h2 className="text-2xl md:text-3xl font-serif leading-relaxed mb-10 text-slate-100">
                      {MOCK_QUESTIONS[currentIdx].q}
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {MOCK_QUESTIONS[currentIdx].a.map((ans, i) => (
                        <button
                          key={i}
                          onClick={() => handleAnswer(i)}
                          className="group relative text-left p-5 md:p-6 rounded-2xl border border-slate-700 bg-slate-800/40 hover:border-amber-500/50 hover:bg-amber-500/5 transition-all cursor-pointer flex items-center gap-4"
                        >
                          <div className="w-10 h-10 rounded-lg bg-slate-950 border border-slate-700 flex items-center justify-center text-sm font-bold text-slate-500 group-hover:text-amber-500 transition-colors shrink-0">
                            {String.fromCharCode(65 + i)}
                          </div>
                          <span className="text-slate-300 group-hover:text-white transition-colors text-lg md:text-xl font-medium leading-tight">{ans}</span>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="explanation"
                    initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                    className="bg-amber-50 p-10 rounded-3xl shadow-2xl text-slate-900 border-t-[12px] border-amber-600 relative z-10"
                  >
                    <div className="flex items-center gap-2 text-amber-700 font-bold mb-6 uppercase tracking-widest text-sm">
                      <BookOpen size={20}/> Penjelasan Sejarah
                    </div>
                    <p className="text-xl md:text-2xl font-serif italic mb-10 leading-relaxed text-slate-800">
                      "{MOCK_QUESTIONS[currentIdx].e}"
                    </p>
                    <button 
                      onClick={() => {
                        if (currentIdx === MOCK_QUESTIONS.length - 1) setGameState('result');
                        else {
                          setCurrentIdx(prev => prev + 1);
                          setTimeLeft(TIMER_TOTAL);
                          setGameState('battle');
                        }
                      }}
                      className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-lg hover:bg-black transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-slate-950/20"
                    >
                      Teruskan Perjalanan <ChevronRight size={24}/>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <footer className="mt-8 flex justify-between items-center text-[10px] uppercase tracking-[0.2em] text-slate-500 font-bold px-2">
              <div className="flex gap-6">
                <span className="flex items-center gap-1.5"><Milestone size={12} /> Peringkat: 0{Math.floor(currentIdx / 10) + 1}</span>
              </div>
              <div className="text-amber-500/60 font-serif lowercase italic text-xs tracking-normal">Soalan {currentIdx + 1} / 40</div>
            </footer>
          </motion.div>
        )}

        {/* RESULT SCREEN */}
        {gameState === 'result' && (
          <motion.div 
            key="result"
            initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className="relative z-10 w-full max-w-2xl bg-slate-900 border border-slate-800 p-10 md:p-16 rounded-[3rem] text-center shadow-2xl backdrop-blur-xl"
          >
            <span className="text-amber-500 uppercase tracking-[0.4em] text-[10px] font-black mb-4 block">Ekspedisi Tamat</span>
            <div className="text-6xl md:text-7xl font-serif font-bold mb-6 tracking-tighter text-slate-100">
              TAMAT!
            </div>
            <p className="text-slate-400 mb-12 text-lg md:text-xl leading-relaxed max-w-md mx-auto">
              Hutan Sejarah telah berjaya diredah. Sila gunakan ilmu yang anda peroleh untuk mengulang kaji pelajaran.
            </p>

            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
              <button 
                onClick={() => setActiveNote('ringkas')}
                className="flex flex-col items-center gap-3 p-6 rounded-3xl bg-slate-800/40 border border-slate-700 hover:border-amber-500 hover:bg-amber-500/5 transition-all group cursor-pointer"
              >
                <FileText className="text-slate-500 group-hover:text-amber-500 transition-colors" size={28} />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 group-hover:text-amber-500 transition-colors">Nota Ringkas</span>
              </button>
              <button 
                onClick={() => setActiveNote('peta')}
                className="flex flex-col items-center gap-3 p-6 rounded-3xl bg-slate-800/40 border border-slate-700 hover:border-amber-500 hover:bg-amber-500/5 transition-all group cursor-pointer"
              >
                <Share2 className="text-slate-500 group-hover:text-amber-500 transition-colors" size={28} />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 group-hover:text-amber-500 transition-colors">Peta Minda</span>
              </button>
              <button 
                onClick={() => setActiveNote('timeline')}
                className="flex flex-col items-center gap-3 p-6 rounded-3xl bg-slate-800/40 border border-slate-700 hover:border-amber-500 hover:bg-amber-500/5 transition-all group cursor-pointer col-span-2 lg:col-span-1"
              >
                <Milestone className="text-slate-500 group-hover:text-amber-500 transition-colors" size={28} />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 group-hover:text-amber-500 transition-colors">Timeline</span>
              </button>
            </div>

            <button 
              onClick={resetGame}
              className="flex items-center gap-3 mx-auto bg-slate-100 text-slate-900 px-10 py-5 rounded-full font-black text-lg hover:bg-amber-500 hover:text-white transition-all cursor-pointer shadow-xl"
            >
              <RotateCcw size={22} /> Cuba Lagi
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* NOTES MODAL */}
      <AnimatePresence>
        {activeNote && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 backdrop-blur-xl bg-slate-950/80"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-[2rem] overflow-hidden flex flex-col max-h-full shadow-2xl"
            >
              <header className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
                <div className="flex items-center gap-3">
                  {activeNote === 'ringkas' && <FileText className="text-amber-500" />}
                  {activeNote === 'peta' && <Share2 className="text-amber-500" />}
                  {activeNote === 'timeline' && <Milestone className="text-amber-500" />}
                  <h2 className="text-xl font-serif font-bold uppercase tracking-wider">
                    {activeNote === 'ringkas' && "Nota Ringkas Form 4"}
                    {activeNote === 'peta' && "Peta Minda Sejarah"}
                    {activeNote === 'timeline' && "Garis Masa Penting"}
                  </h2>
                </div>
                <button 
                  onClick={() => setActiveNote(null)}
                  className="p-2 hover:bg-slate-800 rounded-full transition-colors cursor-pointer"
                >
                  <X size={24} />
                </button>
              </header>

              <div className="flex-grow overflow-y-auto p-8 custom-scrollbar">
                {activeNote === 'ringkas' && (
                  <div className="space-y-12">
                    {NOTA_RINGKAS.map((section, idx) => (
                      <div key={idx} className="group">
                        <h3 className="text-amber-500 font-serif text-2xl mb-4 group-hover:translate-x-2 transition-transform duration-300 flex items-center gap-2">
                          <BookOpen size={20} /> {section.perihal}
                        </h3>
                        <ul className="space-y-3">
                          {section.isi.map((point, pIdx) => (
                            <li key={pIdx} className="flex gap-4 text-slate-300 leading-relaxed bg-slate-800/30 p-4 rounded-xl border border-slate-800/50 hover:bg-slate-800/50 transition-colors">
                              <span className="text-amber-600 font-bold">•</span>
                              {point}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                )}

                {activeNote === 'peta' && (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <Share2 size={64} className="text-slate-800 mb-6" />
                    <h3 className="text-2xl font-serif mb-2">Modul Peta Minda</h3>
                    <p className="text-slate-500 max-w-sm">
                      Peta minda visual sedang disediakan. Sila rujuk nota ringkas buat masa ini.
                    </p>
                    <button className="mt-8 flex items-center gap-2 text-amber-500 font-bold hover:underline">
                      Muat Turun PDF <ExternalLink size={16} />
                    </button>
                  </div>
                )}

                {activeNote === 'timeline' && (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <Milestone size={64} className="text-slate-800 mb-6" />
                    <h3 className="text-2xl font-serif mb-2">Garis Masa Interaktif</h3>
                    <p className="text-slate-500 max-w-sm">
                      Garis masa dari 1941 hingga 1957 sedang dioptimumkan untuk skrin anda.
                    </p>
                  </div>
                )}
              </div>
              
              <footer className="p-6 border-t border-slate-800 bg-slate-900/50 text-center">
                <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                  Hak Cipta Terpelihara &copy; 2026 Hutan Sejarah
                </p>
              </footer>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style jsx global>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #0f172a;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #334155;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #475569;
        }
      `}</style>
    </div>
  );
}